

const ViewQuiz = () => {
    return (
        <div>
            <h1>View Quiz</h1>
        </div>
    )
};

export default ViewQuiz;